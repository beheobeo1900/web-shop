<?php require __DIR__.'/includes/bootstrap.php';$_SESSION=[];session_destroy();session_start();flash('success','Bạn đã đăng xuất.');redirect('index.php');

</main><footer>© <?= date('Y') ?> <?= e(app_name()) ?> — Những món đồ được chọn có chủ đích.</footer></body></html>

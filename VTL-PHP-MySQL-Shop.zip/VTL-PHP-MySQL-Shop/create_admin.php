<?php
// CLI-only tool. Never expose this file through a web server.
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('CLI only'); }
require __DIR__ . '/includes/bootstrap.php';
[$script, $name, $email, $password] = array_pad($argv, 4, '');
if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 12) {
    fwrite(STDERR, "Usage: php create_admin.php 'Admin Name' admin@example.com 'password-at-least-12-chars'\n"); exit(1);
}
try { $s=db()->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')"); $s->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]); echo "Admin created.\n"; }
catch(PDOException $e) { fwrite(STDERR,"Could not create admin (email may already exist).\n"); exit(1); }

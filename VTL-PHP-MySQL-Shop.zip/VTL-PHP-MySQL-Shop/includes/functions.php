<?php
declare(strict_types=1);

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function url(string $path = ''): string { global $config; return ($config['base_url'] ?? '') . '/' . ltrim($path, '/'); }
function app_name(): string { global $config; return $config['app_name'] ?? 'Maison'; }
function media_src(?string $image): string {
    if (!$image) return '';
    if (preg_match('~^https?://~i', $image) || str_starts_with($image, '/')) return $image;
    return url($image);
}
function redirect(string $path): never { header('Location: ' . url($path)); exit; }
function csrf_token(): string { return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">'; }
function verify_csrf(): void { if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf_token'] ?? '')) { http_response_code(419); exit('Invalid request token. Please go back and try again.'); } }
function flash(string $key, ?string $value = null): ?string { if ($value !== null) { $_SESSION['flash'][$key] = $value; return null; } $v = $_SESSION['flash'][$key] ?? null; unset($_SESSION['flash'][$key]); return $v; }
function current_user(): ?array { static $u = false; if ($u !== false) return $u; if (empty($_SESSION['user_id'])) return $u = null; $s = db()->prepare('SELECT id, name, email, role FROM users WHERE id = ?'); $s->execute([$_SESSION['user_id']]); return $u = $s->fetch() ?: null; }
function require_login(): array { $u = current_user(); if (!$u) { flash('error', 'Vui lòng đăng nhập để tiếp tục.'); redirect('login.php'); } return $u; }
function require_admin(): array { $u = require_login(); if ($u['role'] !== 'admin') { http_response_code(403); exit('Forbidden'); } return $u; }
function money(float $amount): string { return number_format($amount, 0, ',', '.') . ' đ'; }
function cart_count(): int { return array_sum($_SESSION['cart'] ?? []); }
function cart_items(): array {
    $cart = $_SESSION['cart'] ?? []; if (!$cart) return [];
    $ids = array_keys(array_filter($cart, fn($q) => (int)$q > 0)); if (!$ids) return [];
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $s = db()->prepare("SELECT id, name, slug, price, image, stock FROM products WHERE is_active=1 AND id IN ($marks)"); $s->execute($ids);
    $items = []; foreach ($s as $p) { $p['qty'] = min((int)$cart[$p['id']], (int)$p['stock']); if ($p['qty']) $items[] = $p; } return $items;
}
function cart_total(array $items): float { return array_sum(array_map(fn($i) => $i['price'] * $i['qty'], $items)); }

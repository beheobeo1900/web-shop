<?php
declare(strict_types=1);

$configFile = __DIR__ . '/../config/config.local.php';
if (!is_file($configFile)) {
    http_response_code(500); exit('Missing config/config.local.php. Copy config/config.php first.');
}
$config = require $configFile;
session_name('shop_session');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax', 'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')]);
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';

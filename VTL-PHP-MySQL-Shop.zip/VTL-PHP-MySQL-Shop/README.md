# Maison — cửa hàng quần áo PHP + MySQL

Cửa hàng trực tuyến nhỏ bằng PHP 8.1+, tiếng Việt: danh mục sản phẩm, giỏ hàng session, thanh toán COD, tài khoản khách và trang quản trị. Mã dùng PDO prepared statement, `password_hash()` / `password_verify()`, token CSRF, chống session fixation, phân quyền theo vai trò, và giao dịch InnoDB khóa dòng tồn kho khi đặt hàng.

## Yêu cầu

- PHP 8.1+ với `pdo_mysql`, MySQL 8+ hoặc MariaDB 10.5+, Apache hoặc Nginx.
- Tiến trình PHP phải đọc được `config/config.local.php`. **Không** đưa tệp này lên mã nguồn công khai.

## Cài đặt (Linux)

1. Tạo tài khoản cơ sở dữ liệu chỉ với quyền cần thiết, rồi nhập lược đồ:

   ```bash
   mysql -u root -p < schema.sql
   mysql -u root -p -e "CREATE USER 'shop_user'@'localhost' IDENTIFIED BY 'use-a-long-random-password'; GRANT SELECT,INSERT,UPDATE,DELETE ON shop.* TO 'shop_user'@'localhost'; FLUSH PRIVILEGES;"
   ```

2. Sao chép `config/config.local.php.example` thành `config/config.local.php`, điền thông tin kết nối và đặt `base_url` là `''` nếu chạy ở gốc virtual host hoặc `/shop` nếu đặt trong thư mục con.
3. Khi phát triển, trong thư mục dự án chạy `php -S localhost:8000`. Với Apache/Nginx, trỏ document root tới thư mục này và tắt liệt kê thư mục.
4. Tạo quản trị viên đầu tiên chỉ trên shell (không qua trình duyệt):

   ```bash
   php create_admin.php 'Quản trị' admin@example.com 'a-unique-password-of-at-least-12-characters'
   ```

   Xóa hoặc chuyển `create_admin.php` sau khi tạo xong, hoặc để ngoài vùng web. Không có tài khoản quản trị mặc định.

## Apache / Nginx

Dùng HTTPS khi triển khai, đặt `base_url` đúng, và chặn HTTP vào `config/`, `includes/`, `schema.sql`, `README.md`, `create_admin.php`.

Ví dụ Nginx:

```nginx
location ~ ^/(config|includes)/ { deny all; }
location ~ ^/(schema\.sql|README\.md|create_admin\.php)$ { deny all; }
```

## Bảo mật

Mọi biểu mẫu ghi dữ liệu đều có CSRF; SQL dùng tham số ràng buộc; mật khẩu được băm. Khi thanh toán, hệ thống đọc lại và khóa tồn kho trong một giao dịch trước khi ghi đơn và trừ kho.

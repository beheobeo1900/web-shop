CREATE DATABASE IF NOT EXISTS shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shop;

CREATE TABLE users (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL, role ENUM('customer','admin') NOT NULL DEFAULT 'customer', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE categories (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(100) NOT NULL, slug VARCHAR(120) NOT NULL UNIQUE) ENGINE=InnoDB;
CREATE TABLE products (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, category_id BIGINT UNSIGNED NOT NULL, name VARCHAR(180) NOT NULL, slug VARCHAR(200) NOT NULL UNIQUE,
 description TEXT NULL, price DECIMAL(12,2) NOT NULL, stock INT UNSIGNED NOT NULL DEFAULT 0, image VARCHAR(500) NULL, is_active TINYINT(1) NOT NULL DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_products_category FOREIGN KEY(category_id) REFERENCES categories(id)
) ENGINE=InnoDB;
CREATE TABLE orders (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_number VARCHAR(30) NOT NULL UNIQUE, user_id BIGINT UNSIGNED NOT NULL,
 recipient_name VARCHAR(120) NOT NULL, phone VARCHAR(30) NOT NULL, address TEXT NOT NULL, payment_method ENUM('cod') NOT NULL DEFAULT 'cod', total DECIMAL(12,2) NOT NULL,
 status ENUM('pending','confirmed','shipping','completed','cancelled') NOT NULL DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_orders_user FOREIGN KEY(user_id) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE order_items (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, order_id BIGINT UNSIGNED NOT NULL, product_id BIGINT UNSIGNED NOT NULL, product_name VARCHAR(180) NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL, quantity INT UNSIGNED NOT NULL, line_total DECIMAL(12,2) NOT NULL,
 CONSTRAINT fk_items_order FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE, CONSTRAINT fk_items_product FOREIGN KEY(product_id) REFERENCES products(id)
) ENGINE=InnoDB;
INSERT INTO categories(name,slug) VALUES ('Áo','ao'),('Quần','quan'),('Phụ kiện','phu-kien');
INSERT INTO products(category_id,name,slug,description,price,stock,image) VALUES
(1,'Áo thun Essential','ao-thun-essential','Cotton dày vừa, form relaxed tối giản.',320000,30,'assets/images/ao-thun.jpg'),
(1,'Sơ mi trắng','so-mi-trang','Sơ mi cotton mềm, form đứng, dễ phối đồ.',590000,18,'assets/images/so-mi.jpg'),
(2,'Quần chino','quan-chino','Dáng ôm vừa, màu khaki, gấu quần có thể gấp.',680000,20,'assets/images/quan.jpg'),
(3,'Túi tote','tui-tote','Túi tote bền, tông be tối giản.',240000,40,'assets/images/tui.jpg');

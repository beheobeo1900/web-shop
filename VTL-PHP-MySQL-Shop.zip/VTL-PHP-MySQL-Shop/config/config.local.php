<?php
return [
  'db' => ['host'=>'shop-db','name'=>'shop','user'=>'shop','pass'=>'shop','charset'=>'utf8mb4'],
  'app_name'=>'Maison', 'base_url'=>'',
];

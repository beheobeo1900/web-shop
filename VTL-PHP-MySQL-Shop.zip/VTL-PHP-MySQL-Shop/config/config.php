<?php
declare(strict_types=1);

// Copy this file to config.local.php and change these values for your server.
return [
    'db' => [
        'host' => getenv('DB_HOST') ?: '127.0.0.1',
        'name' => getenv('DB_NAME') ?: 'shop',
        'user' => getenv('DB_USER') ?: 'user',
        'pass' => getenv('DB_PASS') ?: '',
        'charset' => 'utf8mb4',
    ],
    'app_name' => 'Maison',
    'base_url' => rtrim(getenv('BASE_URL') ?: '', '/'), // e.g. /shop when not virtual-host root
];
